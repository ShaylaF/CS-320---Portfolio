package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        assertDoesNotThrow(() -> {
            service.addContact(contact);
        });
    }

    @Test
    public void testDuplicateContactId() {

        ContactService service = new ContactService();

        Contact contact1 = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        Contact contact2 = new Contact(
                "100",
                "Jane",
                "Doe",
                "0987654321",
                "456 Oak Street");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        assertDoesNotThrow(() -> {
            service.deleteContact("100");
        });
    }

    @Test
    public void testUpdateFirstName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updateFirstName("100", "Jane");

        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updateLastName("100", "Jones");

        assertEquals("Jones", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updatePhone("100", "5555555555");

        assertEquals("5555555555", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updateAddress("100", "456 Oak Street");

        assertEquals("456 Oak Street", contact.getAddress());
    }
}