package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreation() {

        Contact contact = new Contact(
                "100",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        assertEquals("100", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testNullContactId() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Smith",
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLongContactId() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Smith",
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testNullFirstName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("100", null, "Smith",
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testNullLastName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("100", "John", null,
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidPhone() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("100", "John", "Smith",
                    "12345", "123 Main Street");
        });
    }

    @Test
    public void testNullAddress() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("100", "John", "Smith",
                    "1234567890", null);
        });
    }

    @Test
    public void testLongAddress() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "100",
                    "John",
                    "Smith",
                    "1234567890",
                    "This address is definitely more than thirty characters long");
        });
    }
}