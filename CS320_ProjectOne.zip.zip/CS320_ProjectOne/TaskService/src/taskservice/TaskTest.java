package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {

        Task task = new Task(
                "100",
                "Homework",
                "Complete Java assignment");

        assertEquals("100", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete Java assignment",
                task.getDescription());
    }

    @Test
    public void testNullTaskId() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Description");
        });
    }

    @Test
    public void testNullName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("100", null, "Description");
        });
    }

    @Test
    public void testNullDescription() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("100", "Homework", null);
        });
    }

    @Test
    public void testLongTaskId() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345678901",
                    "Homework",
                    "Description");
        });
    }

    @Test
    public void testLongName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "100",
                    "ThisNameIsDefinitelyTooLong",
                    "Description");
        });
    }

    @Test
    public void testLongDescription() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "100",
                    "Homework",
                    "This description is longer than fifty characters and should fail validation.");
        });
    }

    @Test
    public void testTaskIdStoredCorrectly() {

        Task task = new Task(
                "100",
                "Homework",
                "Complete assignment");

        assertEquals("100", task.getTaskId());
    }
}