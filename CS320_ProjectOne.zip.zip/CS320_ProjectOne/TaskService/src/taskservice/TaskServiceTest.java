package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "100",
                "Homework",
                "Complete assignment");

        service.addTask(task);

        assertDoesNotThrow(() -> {
            service.updateName("100", "Project");
        });
    }

    @Test
    public void testAddNullTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(null);
        });
    }

    @Test
    public void testDuplicateTaskId() {

        TaskService service = new TaskService();

        Task task1 = new Task(
                "100",
                "Task1",
                "Description");

        Task task2 = new Task(
                "100",
                "Task2",
                "Description");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "100",
                "Homework",
                "Complete assignment");

        service.addTask(task);

        service.deleteTask("100");

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("100", "Project");
        });
    }

    @Test
    public void testDeleteMissingTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    @Test
    public void testUpdateName() {

        TaskService service = new TaskService();

        Task task = new Task(
                "100",
                "Homework",
                "Complete assignment");

        service.addTask(task);

        service.updateName("100", "Project");

        assertEquals("Project", task.getName());
    }

    @Test
    public void testUpdateDescription() {

        TaskService service = new TaskService();

        Task task = new Task(
                "100",
                "Homework",
                "Complete assignment");

        service.addTask(task);

        service.updateDescription(
                "100",
                "Updated description");

        assertEquals(
                "Updated description",
                task.getDescription());
    }

    @Test
    public void testUpdateMissingTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("999", "Project");
        });
    }
}