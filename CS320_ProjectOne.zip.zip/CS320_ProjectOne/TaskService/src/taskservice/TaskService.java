package taskservice;


import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {

        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Duplicate task ID");
        }

        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {

        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }

        tasks.remove(taskId);
    }

    private Task getTaskOrThrow(String taskId) {

        Task task = tasks.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }

        return task;
    }

    public void updateName(String taskId, String name) {

        getTaskOrThrow(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {

        getTaskOrThrow(taskId).setDescription(description);
    }
}

