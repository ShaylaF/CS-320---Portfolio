package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "100",
                futureDate,
                "Doctor Visit");

        assertEquals("100", appointment.getAppointmentId());
        assertEquals("Doctor Visit", appointment.getDescription());
        assertEquals(futureDate, appointment.getAppointmentDate());
    }

    @Test
    public void testNullAppointmentId() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor Visit");
        });
    }

    @Test
    public void testLongAppointmentId() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor Visit");
        });
    }

    @Test
    public void testNullDate() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", null, "Doctor Visit");
        });
    }

    @Test
    public void testPastDate() {

        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", pastDate, "Doctor Visit");
        });
    }

    @Test
    public void testNullDescription() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", futureDate, null);
        });
    }

    @Test
    public void testLongDescription() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "100",
                    futureDate,
                    "This description is definitely longer than fifty characters and should fail validation.");
        });
    }
}