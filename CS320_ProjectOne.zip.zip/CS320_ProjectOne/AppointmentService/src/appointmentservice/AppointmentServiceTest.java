package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "100",
                futureDate,
                "Doctor Visit");

        assertDoesNotThrow(() -> {
            service.addAppointment(appointment);
        });
    }

    @Test
    public void testDuplicateAppointmentId() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment1 = new Appointment(
                "100",
                futureDate,
                "Doctor Visit");

        Appointment appointment2 = new Appointment(
                "100",
                futureDate,
                "Dental Visit");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "100",
                futureDate,
                "Doctor Visit");

        service.addAppointment(appointment);

        assertDoesNotThrow(() -> {
            service.deleteAppointment("100");
        });
    }

    @Test
    public void testDeleteMissingAppointment() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}